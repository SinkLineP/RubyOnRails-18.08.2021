class CreateBarbers < ActiveRecord::Migration[5.2]

	def change    

  	create_table :barbers do |t|
  		t.text :name

  		t.timestamp
  	end

	 	# Barber.create :name => 'Jessie Pickman'
	 	# Barber.create :name => 'Walter White'
	 	# Barber.create :name => 'Gus Fring'

  end
end
