import React from 'react';
import './footer.scss';

const Footer = ({author, designer}) => {

	return (
		<footer className="footer">
			<div className="container">
			
			<div className="colorfooter">
      <p className="footer-nav-text">
      Сайт був розроблений <span className="text-yellow">{author}</span>, в яку входять <span className="text-yellow">{designer}</span>
				
             

        	</p>
          </div>		
				<p className="footer-text">
        2020, Всі права захищені	<br/><br/>
        Згода на обробку персональних даних <br/><br/>
        Політика конфіденційності
				</p>
			</div>
		</footer>
	);
};

export default Footer;