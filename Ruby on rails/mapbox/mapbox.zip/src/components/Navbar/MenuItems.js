export const MenuItems = [
    {
        title: 'Home',
        url: '#home/',
        cName: 'nav-links'
    },
    {
        title: 'Servises',
        url: '#servises/',
        cName: 'nav-links'
    },
    {
        title: 'Products',
        url: '#products/',
        cName: 'nav-links'
    },
    {
        title: 'Contact us',
        url: '#contactus/',
        cName: 'nav-links'
    },
    // {
    //     title: 'Sign up',
    //     url: '#signup/',
    //     cName: 'nav-links-1'
    // }
];