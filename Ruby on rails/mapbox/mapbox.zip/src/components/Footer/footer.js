import React from 'react';
import "./footer.scss";

const Footer = ({}) => {
  // const line = [
      
  // ];


  return (
    <div>
      <div classNane="line"></div>
      <footer className="footer">
       
      <div className="main-footer">


        <table>
          <tr>
            <td>
              <a href="#">
                Text
            </a>

            </td>
            <td>
              <a href="#">
                Text
            </a>
            </td>
            <td>
              <a href="#">
                Text
            </a>
            </td>
          </tr>

          <tr>
            <td>
              <a href="#">
                Text
            </a>
            </td>
            <td>
              <a href="#">
                Text
            </a>
            </td>
            <td>
              <a href="#">
                Text
            </a>
            </td>
          </tr>

          <tr>
            <td>
              <a href="#">
                Text
            </a>
            </td>
            <td>
              <a href="#">
                Text
            </a>
            </td>
            <td>
              <a href="#">
                Text
            </a>
            </td>
          </tr>

          <tr>
            <td>
              <a href="#">
                Text
            </a>
            </td>
            <td>
              <a href="#">
                Text
            </a>
            </td>
            <td>
              <a href="#">
                Text
            </a>
            </td>
          </tr>
        </table>
        
 
        <div className="follow-us">
          слідкуйте за нами
        <div className="social-media">
          <a href="#"><i className="fab fa-facebook fa-2x"></i></a>
          <a href="#"><i className="fab fa-instagram fa-2x"></i></a>
          <a href="#"><i className="fab fa-twitter fa-2x"></i></a>
        </div>

        <div> 
          powered by "IT Nation Hacks" team "МАРС (Майстри революційних систем)"
        </div>
      
            <a href="#"> <img src="images/mars-logo.png" className="main-links"  /> </a>
        </div>
      </div>
          <div className="main-footer">
            <div className="number">
              Якщо Вам потрібна допомога з публічним файлом, звертайтесь за номером
            </div>
          </div>
      
        <hr />
          <div className="main-footer-footer">
            <img src="images/UNESCO_Logo.png" />
              <div >Copyright © 2020 Всі права захищені</div>
              <img src="images/mon.png" />
          </div>

      
      </footer>
    </div>
    );


};

export default Footer;