import React from 'react';
import './App.scss';
import Mapbox from './components/Mapbox/mapbox';
import Navbar from './components/Navbar/Navbar';
import Footer from './components/Footer/footer';

function App() {




  return (
    <>
      <div className="App">
        <Navbar/>
        <Mapbox/>
        <Footer/>
      </div>
    </>
  );
}

export default App;
