import React from 'react';
import logo from './logo.svg';
import './App.css';
import './myStyles.css'

function App() {
  return (
    <div>
      <header>
      Дошка пошани
    </header>
    <div class="container">
      <div class="block">
      <div class="header-block">
        Юні танцюристи з Луганська завоювали перші місця на турнірі з бальних танців в Москві
      </div>
      <div class="main-block">
     <img src={require('./images/1569923047_img_6701.jpg')} alt="wasd"></img>
      <div class="text-block">
      У класифікаційних змаганнях юна пара Олександра Сафонова і Анастасії Новікової завоювала перше місце відразу в двох категоріях - діти 8-9 років (N3) і діти 8-9 років (N4).
У ЛУВО відзначили, що турнір «Осіння Москва» є значущою подією в культурному танцювального життя столиці Росії і знаходить з кожним роком все більших масштабів.
      </div>
    </div>
      </div>

      <div class="block margin-top">
      <div class="header-block">
      Перші місця учнів з Сєвєродонецька
      </div>
      <div class="main-block">
     <img src={require('./images/3ba4ed4143c575a44264b4a4fcc3e70a_crop.jpg')} alt="wasd"></img>
      <div class="text-block">
      Діти з Сєвєродонецької школи №20 займають перші місця з танців
      </div>
    </div>
      </div>

      <div class="block margin-top">
      <div class="header-block">
        Юні танцюристи з Луганська завоювали перші місця на турнірі з бальних танців в Москві
      </div>
      <div class="main-block">
     <img src={require('./images/0000000.jpeg')} alt="wasd"></img>
      <div class="text-block">
      У класифікаційних змаганнях юна пара Олександра Сафонова і Анастасії Новікової завоювала перше місце відразу в двох категоріях - діти 8-9 років (N3) і діти 8-9 років (N4).
У ЛУВО відзначили, що турнір «Осіння Москва» є значущою подією в культурному танцювального життя столиці Росії і знаходить з кожним роком все більших масштабів.
      </div>
    </div>
      </div>
    
    </div>
    
    </div>
    
  );
}

export default App;
